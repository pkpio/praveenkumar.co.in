<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Text to Gregg Converter</title>


<link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
</head>
<body>
<div id="header"></div>
<div id="content">
<div id="form">
<input type ="text" id="input" placeholder="Enter the word"/>
<input type="button" id="button" value="To Gregg" onclick="startDrawing(document.getElementById('input').value);"/>
</div>
 <div id="canvas"></div>
</div>
<div id="footer"></div>
 <script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/jsDraw2D.js"></script>
<script language="javascript" type="text/javascript">
var x_offset,y_offset, scale ;
var canvasDiv=document.getElementById("canvas");
var gr=new jsGraphics(canvasDiv);
scale = 50;
x_offset = 100;
y_offset = 200;

</script>
</body>
</html>