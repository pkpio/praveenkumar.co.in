function startDrawing (word){
  x_offset = 100;
  y_offset = 200;
  var letter, j;
  gr.clear();
  letter = word.split(" ");

  for ( j = 0; j < letter.length; j++) {
    if (letter[j] == 'a'|| letter[j] == 'e' ){
          drawPolyBezier(letter[j]+'1') ;
          drawPolyBezier(letter[j]+'2') ;
          drawPolyBezier(letter[j]+'3') ;
          drawPolyBezier(letter[j]+'4') ;
    }
    else   drawPolyBezier(letter[j])  ;
  }
  return false;
}

function drawPolyBezier(let) {
  var i, pen , letter, col, points ;

    col = new jsColor('#004C99');
    pen = new jsPen(col, 2);


        points = new Array();
        points = BezierPointsof(let);

        for (i = 0; i < points.length; i++) {
            points[i].x = points[i].x * scale + x_offset;
            points[i].y = points[i].y * scale + y_offset;
            gr.fillRectangle(new jsColor("black"), new jsPoint((points[i].x) - 1, (points[i].y) - 1), 3, 3);

        } ;

         gr.drawPolyBezier(pen, points);

        x_offset = points[points.length - 1].x;
        y_offset = points[points.length - 1].y;

      return true;

}

function BezierPointsof(letter) { 
    var pnts = new Array();
    var t70 = 2.74;
    var t20 = 0.36;
    var kappa = 0.55;
    var rad_a = 0.2;
    var rad_e = 0.05;

    switch (letter) {
    case 'k':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((1 + 1 / (t70 * t70 - 1)) * 0.6, (t70 * 0.6 / (1 - t70 * t70)));
        pnts[1] = new jsPoint((pnts[2].x / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((0.6 + pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(0.6, 0);


        break;
    case 'g':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((1 + 1 / (t70 * t70 - 1)), (t70 / (1 - t70 * t70)));
        pnts[1] = new jsPoint((pnts[2].x / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((1 + pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(1, 0);


        break;
    case 'r':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((1 + 1 / (t20 * t20 - 1)) * 0.6, (t20 * 0.6 / (1 - t20 * t20)));
        pnts[1] = new jsPoint((pnts[2].x / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((0.6 + pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(0.6, 0);


        break;
    case 'l':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((1 + 1 / (t20 * t20 - 1)), (t20 / (1 - t20 * t20)));
        pnts[1] = new jsPoint((pnts[2].x / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((1 + pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(1, 0);


        break;
    case 'n':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(0.51, 0);

        break;
    case 'm':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(1, 0);

        break;
    case 't':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(0.5, -0.5 * t20);

        break;
    case 'd':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(1, -t20);

        break;
    case 'ch':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(-0.25, 0.25 * t70);

        break;
    case 'j':
        pnts[0] = new jsPoint(0, 0);
        pnts[1] = new jsPoint(-0.5, 0.5 * t70);

        break;
    case 'p':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((0.6 / (t20 * t20 - 1)), (t20 * 0.6 / (t20 * t20 - 1)));
        pnts[1] = new jsPoint(((pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((pnts[2].x - 0.6) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(-0.6, 0);

        pnts = rotate(pnts, 65);

        break;

    case 'b':
        pnts[0] = new jsPoint(0, 0);
        pnts[2] = new jsPoint((1 / (t20 * t20 - 1)), (t20 / (t20 * t20 - 1)));
        pnts[1] = new jsPoint(((pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((pnts[2].x - 1) / 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(-1, 0);

        pnts = rotate(pnts, 65);

        break;

    case 'v':

        pnts[0] = new jsPoint(0 , 0);
        pnts[2] = new jsPoint((1 / (t70 * t70 - 1)), (t70 / (t70 * t70 - 1)));
        pnts[1] = new jsPoint(((pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((pnts[2].x - 1 )/ 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(-1, 0);
        pnts = rotate(pnts, 65);

        break;
    case 'f':
       pnts[0] = new jsPoint(0 , 0);
        pnts[2] = new jsPoint((0.6 / (t70 * t70 - 1)), (t70*0.6 / (t70 * t70 - 1)));
        pnts[1] = new jsPoint(((pnts[2].x) / 2), (pnts[2].y / 2));
        pnts[3] = new jsPoint(((pnts[2].x - 0.6 )/ 2), (pnts[2].y / 2));
        pnts[4] = new jsPoint(-0.6, 0);
        pnts = rotate(pnts, 65);

        break;
   case 'a1':
        pnts[0] = new jsPoint(0 , 0);
        pnts[1] = new jsPoint(kappa*rad_a,0);
        pnts[2] = new jsPoint(rad_a, -rad_a*(1-kappa));
        pnts[3] = new jsPoint(rad_a, -rad_a);
         break;
   case 'a2':
        pnts[0] = new jsPoint(0,0);
        pnts[1] = new jsPoint(0, -rad_a*kappa);
        pnts[2] = new jsPoint(-rad_a*(1-kappa),-rad_a);
        pnts[3] = new jsPoint(-rad_a,-rad_a);
         break;
    
    case 'a3' :
         pnts[0] = new jsPoint(0,0);
          pnts[1] = new jsPoint(-rad_a*kappa,0);
        pnts[2] = new jsPoint(-rad_a, rad_a*(1-kappa));
        pnts[3] = new jsPoint(-rad_a,rad_a);
         break;
    case 'a4' :

        pnts[0] = new jsPoint(0,0);
        pnts[1] = new jsPoint(0, rad_a*kappa);
        pnts[2] = new jsPoint((1-kappa)*rad_a,rad_a);
        pnts[3] = new jsPoint(rad_a,rad_a);


        break;
    case 'e1':
        pnts[0] = new jsPoint(0 , 0);
        pnts[1] = new jsPoint(kappa*rad_e,0);
        pnts[2] = new jsPoint(rad_e, -rad_e*(1-kappa));
        pnts[3] = new jsPoint(rad_e, -rad_e);
         break;
   case 'e2':
        pnts[0] = new jsPoint(0,0);
        pnts[1] = new jsPoint(0, -rad_e*kappa);
        pnts[2] = new jsPoint(-rad_e*(1-kappa),-rad_e);
        pnts[3] = new jsPoint(-rad_e,-rad_e);
         break;
    
    case 'e3' :
         pnts[0] = new jsPoint(0,0);
          pnts[1] = new jsPoint(-rad_e*kappa,0);
        pnts[2] = new jsPoint(-rad_e, rad_e*(1-kappa));
        pnts[3] = new jsPoint(-rad_e,rad_e);
         break;
    case 'e4' :

        pnts[0] = new jsPoint(0,0);
        pnts[1] = new jsPoint(0, rad_e*kappa);
        pnts[2] = new jsPoint((1-kappa)*rad_e,rad_e);
        pnts[3] = new jsPoint(rad_e,rad_e);


        break;
    default:
        pnts[0] = new jsPoint(0, 0);
        break;
    }
    return pnts;
}

function rotate(p, deg) {
    var rot_p = new Array();
    var c = Math.cos(deg * Math.PI / 180);
    var s = Math.sin(deg * Math.PI / 180);
    for (var i = 0; i < p.length; i++) {
        rot_p[i] = new jsPoint(p[i].x * c + p[i].y * s, -p[i].x * s + p[i].y * c);
    }
    return rot_p;

}